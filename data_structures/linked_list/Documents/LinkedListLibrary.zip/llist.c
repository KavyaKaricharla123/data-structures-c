/**
 * Linked List Library.  Includes standard functions for insertion, deletion, 
 * membership, length, replacement, printing linked lists, etc.
 * 
 * @brief Linked List Library
 * 
 * @file llist.c
 * @author Kevin Browne
 * @date Wednesday May 12th, 2021.
 * 
 */ 
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "llist.h"

/**
 * Merges two sorted lists (from lowest to highest node values) into a single 
 * sorted list.
 * 
 * @brief Merges two sorted lists
 * 
 * @param pointer to head of the first list
 * @param pointer to head of the second list
 * @return pointer to head of the merged list
 */ 
Node *merge_sorted_lists(Node *list1, Node *list2)
{
  // if either list is empty, just return the other list
  if (list1 == NULL) return list2; 
  if (list2 == NULL) return list1;  

  // used to keep track of the current node in each list, new head, and 
  // current node in the new list
  Node *l1current, *l2current;
  Node *new_head, *newcurrent;
  l1current = list1; 
  l2current = list2;

  // determine the head of the new list
  if (l1current->value <= l2current->value)
  {
    new_head = l1current;
    l1current = l1current->next;
  }
  else 
  {
    new_head = l2current;
    l2current = l2current->next;
  }
  newcurrent = new_head;

  // traverse both lists, re-arranging next pointers into a new list
  while (l1current != NULL && l2current != NULL)
  {
    // if the list1 node has the smaller value, make that the next node 
    // in the new list, and continue to traverse list1
    if (l1current->value <= l2current->value)
    {
      newcurrent->next = l1current;
      newcurrent = l1current;
      l1current = l1current->next;
    }
    // same as above, but for list2
    else 
    {
      newcurrent->next = l2current;
      newcurrent = l2current; 
      l2current = l2current->next;
    }
  }

  // if we reach the end of a list, append what remains of the other list
  if (l1current == NULL)
  {
    newcurrent->next = l2current;
  }
  else if (l2current == NULL)
  {
    newcurrent->next = l1current;
  }

  return new_head;
}

/**
 * Duplicates a list by creating a copy of the list on the heap.  i.e. a list 
 * with the same number of nodes and same value at each corresponding node.
 * The function works by recursively duplicating each node, and setting up 
 * the next pointer to point to the duplicate of the next node.
 * 
 * @brief Duplicates a list
 * 
 * @param node pointer to head of the list to be duplicated
 * @return pointer to head of the duplicate list
 */ 
Node *duplicate_list(Node *node)
{
  // the duplicate of an empty list (or tail pointer) is NULL
  if (node == NULL) return NULL;

  // create the duplicate node on the heap
  Node *new_node = calloc(sizeof(Node), 1);
  new_node->value = node->value;

  // have the duplicate node point to the duplicate of the next node
  new_node->next = duplicate_list(node->next);

  // return the duplicate node
  return new_node;
}

/**
 * Adds the values of corresponding nodes in two lists together and stores 
 * the result in the first list.  Recursively traverses both lists, stopping
 * the additions when the end of one list is reached.
 * 
 * @brief Adds corresponding node values of two lists together
 * 
 * @param list1 pointer to the first list, the result is stored in this list
 * @param list2 pointer to the second list
 * @return nothing
 */ 
void add_lists(Node *list1, Node *list2)
{
  if (list1 == NULL || list2 == NULL) return ;
  list1->value = list1->value + list2->value;
  add_lists(list1->next, list2->next);
}

/**
 * Deletes a list by recursively traversing the list and free-ing each node 
 * on the heap.
 * 
 * @brief Deletes a list
 * 
 * @param node pointer to the list to be deleted
 * @return nothing
 */ 
Node *delete_list(Node *node)
{
  if (node != NULL)
  {
    delete_list(node->next);
    free(node);
  }
  return NULL;
}

/**
 * Inserts a new node in a linked list after the first occurrence of a node 
 * with a given value.  If no node with that value occurs in the list, the 
 * new node is inserted at the tail (including for an empty list).
 * 
 * @brief Inserts a new node in a linked list after a given value
 * 
 * @param head pointer to head of the list to insert a new node
 * @param new_value the value to insert at a new node in the list
 * @param after_value the value after which to insert the new node
 * @return pointer to the potentially new head of the list
 */ 
Node *insert_after(Node *head, int new_value, int after_value)
{
  // Create the new node to insert
  Node *new_node = calloc(1, sizeof(Node));
  new_node->value = new_value;
  
  // if it's an empty list, the new node IS the list!
  if (head == NULL) return new_node; 
  else
  {
    // Otherwise traverse the list until we reach the tail
    Node *current = head;
    while (current->next != NULL)
    {
      // if we find the value to insert the new node after, insert it, and 
      // return the head of the list because the work is done
      if (current->value == after_value)
      {
        new_node->next = current->next; 
        current->next = new_node;
        return head;
      }
      else current = current->next;
    }

    // if we reach the tail of the list, insert the new node here
    new_node->next = current->next;
    current->next = new_node;
    return head;
  }
}

/**
 * Deletes nodes with duplicate values from a list, leaving only the first 
 * node in a list with a given value remaining.
 * 
 * @brief Deletes duplicates from a list
 * 
 * @param head pointer to head of the list to delete duplicates
 * @return nothing
 */ 
void delete_duplicates(Node *head)
{
  // empty lists and lists with one node have no duplicates!
  if (head == NULL) return ;
  if (head->next == NULL) return ;

  // We use current1 and current2 to traverse the list
  Node *current1, *current2, *duplicate;
  current1 = head;

  // The outter loop "increments" current1 (i.e. traverses to the next node) 
  // after removing any nodes with duplicate values to current1
  while (current1 != NULL && current1->next != NULL)
  {

    // The inner loop uses current2 to traverse the list
    current2 = current1;
    while (current2->next != NULL)
    {
      // Whenever current1's value is equal to the value in the next node 
      // that current2 points to, we delete that node from the list and have 
      // current2 point to the node after the next node ("the next next node")
      if (current1->value == current2->next->value)
      {
        duplicate = current2->next;
        current2->next = current2->next->next;
        free(duplicate);
      }
      // if what current 2 is pointing to doesn't contain a duplicate, just 
      // have current2 point to the next node and keep checking for duplicates
      else current2 = current2->next;
    }

    // have current1 point to the next node in the list
    current1 = current1->next;
  }
}

/**
 * Sorts a list from lowest to highest values beginning with head using the
 * bubble sort algorithm: https://en.wikipedia.org/wiki/Bubble_sort
 * Note that we only swap node values rather than re-arrange node pointers
 * themselves.
 * 
 * @brief Sorts a list
 * 
 * @param head pointer to head of the list to sort
 * @return nothing
 */ 
void sort_list(Node *head)
{
  // An empty list or a list of one node are already sorted, just return them
  if (head == NULL) return ;
  if (head->next == NULL) return ;

  bool swapped = false;

  // keep attempting to swap node values until no swap occurs
  do 
  {
    swapped = false;
    Node *current = head;
    Node *prev = NULL;

    // keep track of the next and previous nodes while traversing the list
    while (current->next != NULL)
    {
      prev = current;
      current = current->next;

      // swap node values if they are not in the correct order
      if (current != NULL)
      {
        if (current->value < prev->value)
        {
          int temp;
          temp = prev->value;
          prev->value = current->value;
          current->value = temp;
          swapped = true;
        }
      }
    }
  } while (swapped);
}

/**
 * Reverses a linked list starting with head and returns the new head of the
 * reversed list.  By reverse the list, we mean reverse the direction of all
 * the pointers in the list.
 * 
 * @brief Reverses a list
 * 
 * @param head pointer to head of the list to reverse
 * @return pointer to the potentially new head of the list
 */ 
Node *reverse_list(Node *head)
{
  // do nothing in the case of an empty list
  if (head == NULL) return NULL;

  // a list with one node is identical to it's "reversal"
  if (head->next == NULL) return head;

  // will need to keep track of two nodes to perform reversal
  Node *current = head;
  Node *next_node = head->next;

  // current head becomes the tail, so points to NULL!
  current->next = NULL; 

  // traverse through the list until we reach the (old) tail
  while (next_node != NULL)
  {
    // Reverse the pointer, so that next_node points to current. 
    // Then set the next_node to whatever the next_node was previously 
    // pointing to (with the assistance of a temp value), and set current 
    // to the old next_node.
    Node *tmp = next_node->next;
    next_node->next = current; 
    current = next_node;
    next_node = tmp;
  }

  // the previous tail becomes the new head!
  return current;
}

/**
 * Appends the list beginning with head2 to the tail of the list beginning with
 * head1, returns the potentially new head of the list.
 * 
 * @brief Appends a list to another list
 * 
 * @param head1 pointer to head of the first list
 * @param head2 pointer to head of the list to append to the first list
 * @return pointer to the potentially new head of the first list
 */ 
Node *append_list(Node *head1, Node *head2)
{
  // if the first list is empty, the 2nd list's head becomes the beginning of 
  // the new list
  if (head1 == NULL) return head2;

  // Otherwise traverse the first list until we reach the tail, and set the 
  // tail of the list to point to the head of the list to be appended
  Node *current = head1;
  while (current->next != NULL) current = current->next;
  current->next = head2;
  return head1;
}

/**
 * Deletes matching values from a list.  Does so in an efficient way by 
 * traversing the list only once.  Keeps a count of how many deletions occur.
 * 
 * @brief Efficiently deletes matching values from a list
 * 
 * @param head pointer to head of the list to delete matching values
 * @param delete_value the value to delete from the list
 * @param num_deleted pass-by-reference parameter to count deletions that occur
 * @return pointer to the potentially new head of the list
 */ 
Node *efficient_delete_match(Node *head, int delete_value, int *num_deleted)
{
  *num_deleted = 0;
 
  // we can delete nothing from an empty list
  if (head == NULL) return NULL;

  Node *current, *temp, *new_head;

  // traverse the list and delete any matches from the head of the list, the 
  // first non-matching value becomes the new head of the list
  current = head;
  while (current->value == delete_value)
  {
    temp = current;
    current = current->next;
    free(temp);
    *num_deleted = *num_deleted + 1;

    // if we reach the tail, all values have matched and the list is now empty!
    if (current == NULL) return NULL;
  }
  new_head = current;

  // traverse the remainder of the list, deleting nodes with matching values
  while (current->next != NULL)
  {
    if (current->next->value == delete_value)
    {
      temp = current->next;
      current->next = current->next->next;
      free(temp);
      *num_deleted = *num_deleted + 1;
    }
    else current = current->next;
  }

  return new_head;
}

/**
 * Deletes all nodes with a value matching delete_value in a linked list
 * by repeatedly calling delete_first_match until no matches are found making
 * the implementation not very efficient.  Keeps track of the number of nodes
 * deleted.
 * 
 * @brief Deletes matching values from a list
 * 
 * @param head pointer to head of the list to delete matching values
 * @param delete_value the value to delete from the list
 * @param num_deleted pass-by-reference parameter to count deletions that occur
 * @return pointer to the current head of the list after deletions
 */ 
Node *delete_all_matches(Node *head, int delete_value, int *num_deleted)
{
  Node *current = head;
  bool deleted = false;
  *num_deleted = 0;

  // keep calling delete_first_match until nothing is deleted 
  do 
  {
    current = delete_first_match(current, delete_value, 
                                 &deleted);
    if (deleted) *num_deleted = *num_deleted + 1;
  } while (deleted);

  return current;
}

/**
 * Deletes the first node from a linked list that matches a value. Keeps track 
 * of whether a deletion has occurred or not (the value may just not be in the
 * list at all). 
 * 
 * @brief Deletes a matching value from a list
 * 
 * @param head pointer to head of the list to a delete matching value
 * @param delete_value the value to delete from the list
 * @param was_deleted pass-by-reference parameter, true/false if deletion occurs
 * @return pointer to the current head of the list after potential deletion
 */ 
Node *delete_first_match(Node *head, int delete_value, bool *was_deleted)
{
  // if the list is empty, no delete occurs, and return empty list
  if (head == NULL)
  {
    *was_deleted = false;
    return NULL;
  }

  // if the head node needs to be deleted, return the next node as the new head
  // of the list (which could be null), and free the existing head node
  if (head->value == delete_value)
  {
    Node *temp = head->next;
    free(head);
    *was_deleted = true;
    return temp;
  }

  Node *current = head->next;
  Node *prev = head;

  // Traverse list keeping track of node previous to the current, if the 
  // current node needs to be deleted, free the current node and have the 
  // previous node point to what the current node was pointing to.  In this 
  // case the head of our list has not changed so we can return the same head.
  while (current != NULL)
  {
    if (current->value == delete_value)
    {
      prev->next = current->next;
      free(current);
      *was_deleted = true;
      return head;
    }
    prev = current;
    current = current->next;
  }

  // if no deletion occurred 
  *was_deleted = false;
  return head;
}

/**
 * Recursively traverses the list starting with replacing occurences of a 
 * value with another value.
 * 
 * @brief Replaces occurrences of a value in a list
 * 
 * @param node pointer to head of the list to replace matches in
 * @param find_value the value to replace
 * @param replace_value the replacement value
 * @return nothing
 */ 
void replace_matches(Node *node, int find_value, int replace_value)
{
  if (node != NULL)
  {
    if (node->value == find_value) node->value = replace_value;
    replace_matches(node->next, find_value, replace_value);
  }
}

/**
 * Recursively traverses the list counting the number of matching values in the 
 * list.
 * 
 * @brief Counts matches in a list
 * 
 * @param node pointer to head of the list 
 * @param find_value value to find in the list
 * @return number of matching values in the list
 */ 
int count_matches(Node *node, int find_value)
{
  if (node == NULL) return 0;
  else if (node->value == find_value) 
    return 1 + count_matches(node->next, find_value);
  else return count_matches(node->next, find_value);
}

/**
 * Recursively traverses the list checking for the presence of a value in the 
 * list.
 * 
 * @brief Checks if a value is in a list or not
 * 
 * @param node pointer to head of the list 
 * @param find_value value to find in the list
 * @return true/false if a value is in the list or not
 */ 
bool is_member(Node *node, int find_value)
{
  if (node == NULL) return false;
  else if (node->value == find_value) return true;
  else return is_member(node->next, find_value);
}

/**
 * Recursively traverses the list to calculate the list length.
 * 
 * @brief Returns the list length via recursion
 * 
 * @param node pointer to head of the list 
 * @return the length of the list
 */ 
int recursive_length(Node *node)
{
  if (node == NULL) return 0;
  else return 1 + recursive_length(node->next);
}

/**
 * Traverses the list to calculate the list length.
 * 
 * @brief Returns the list length
 * 
 * @param node pointer to head of the list 
 * @return the length of the list
 */ 
int length(Node *head)
{
  Node *current;
  current = head;
  int length = 0;

  // traverse the list until we reach the tail, counting each node in length
  while (current != NULL)
  {
    length++;
    current = current->next;
  }

  return length;
}

/**
 * Deletes the node at the tail of the list.  If the list is empty, it 
 * does nothing.  If the list only has one node, it returns an empty list.
 * 
 * @brief Deletes node at tail of a list
 * 
 * @param head pointer to head of the list 
 * @return the potentially new head of the list
 */ 
Node *delete_at_tail(Node *head)
{
  // if the list is empty, we can delete nothing
  if (head == NULL) return NULL; 
  // if the list only contains one node, delete the node, return an empty list
  else if (head->next == NULL)
  {
    free(head);
    return NULL;
  }
  else 
  {
    Node *current = head;
    Node *prev = NULL;

    // traverse the list until we reach the tail, using prev to keep track of 
    // the node previous to the tail node
    while (current->next != NULL)
    {
      prev = current;
      current = current->next;
    }

    // delete the tail node, make the previous node the new tail
    prev->next = NULL;
    free(current);

    return head;
  }
}

/**
 * Deletes the node at the head of the list.  If the list is empty, it 
 * does nothing.  
 * 
 * @brief Deletes node at head of a list
 * 
 * @param head pointer to head of the list 
 * @return the new head of the list
 */ 
Node *delete_at_head(Node *head)
{
  // if the list is empty, we can't delete anything
  if (head == NULL) return NULL;
  // otherwise delete the head node, return the next node as the head (it might
  // be NULL if the list only has one node, in which case we are returning an
  // empty list as expected)
  else 
  {
    Node *to_return = head->next;
    free(head);
    return to_return;
  }
}

/**
 * Inserts a node at the tail of a list.
 * 
 * @brief Inserts a node at the tail of a list
 * 
 * @param head pointer to head of the list 
 * @param new_value the value for the new node in the list
 * @return the potentially new head of the list
 */ 
Node *insert_at_tail(Node *head, int new_value)
{
  // Create the new node
  Node *new_node = calloc(1, sizeof(Node));
  new_node->value = new_value;

  // if the list is empty, the new node IS the new list so return it
  if (head == NULL) return new_node;
  // otherwise traverse the list until we reach the tail and insert the node
  else 
  {
    Node *current = head;
    while (current->next != NULL) current = current->next;
    current->next = new_node;
    return head;
  }  
}

/**
 * Inserts a node at the head of a list.
 * 
 * @brief Inserts a node at the head of a list
 * 
 * @param head pointer to head of the list 
 * @param new_value the value for the new node in the list
 * @return the new head of the list
 */ 
Node *insert_at_head(Node *head, int new_value)
{
  // Create the new node
  Node *new_node = calloc(1, sizeof(Node));
  new_node->value = new_value;

  // if the list is empty, the new node IS the new list so return it
  if (head == NULL) return new_node;
  // otherwise have the node point to the head, and return it AS the new head
  else 
  {
    new_node->next = head;
    return new_node;
  }
}

/**
 * Prints each list node by traversing the list until reaching the tail. Keeps
 * track of an "index" and prints this as well.
 * 
 * @brief Prints a list
 * 
 * @param head pointer to head of the list 
 * @return nothing
 */ 
void print_list(Node *head)
{
  Node *current;
  current = head;
  int i = 0;
  while (current != NULL)
  {
    printf("Node %d: %d\n", i, current->value);
    i++;
    current = current->next;
  }
}
