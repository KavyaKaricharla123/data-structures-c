/**
 * The main function includes various function calls to test out the linked
 * list library.
 * 
 * @brief Linked List Library test code
 * 
 * @file main.c
 * @author Kevin Browne
 * @date Wednesday May 12th, 2021.
 * 
 */ 
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "llist.h"

/**
 * Tests all functions in the linked list library, including some performance 
 * tests of interest.
 * 
 * @brief Tests linked list library functions.
 * 
 * @return 0
 */
int main()
{
  // Even though most data structures exist on the heap, we can technically 
  // create them on the stack too...
  Node a, b, c;
  a.value = 5;
  b.value = 6;
  c.value = 7;

  // By setting a.next to point to b, and b.next to point to c, we've now 
  // created a linked list by chaining them together.  Since c is the last 
  // node in our list, we set it to point to NULL.
  a.next = &b;
  b.next = &c;
  c.next = NULL;

  printf("\nprint_list test\n");
  printf("****************************************\n\n");

  // We can print out each node's value
  printf("a.value: %d\n", a.value);
  printf("b.value: %d\n", b.value);
  printf("c.value: %d\n\n", c.value);

  // Print out the list using the print_list method
  print_list(&a);
  printf("\n");


  // More typically data structures exist on the heap and functions are 
  // created to manipulate them (insert, delete, etc.).  Here we start off 
  // with a "blank list", i.e. a pointer to NULL.
  Node *list1_head = NULL;

  // Test out the function to insert elements at the head of the list
  printf("\ninsert_at_head test\n");
  printf("****************************************\n\n");
  list1_head = insert_at_head(list1_head, 7);
  list1_head = insert_at_head(list1_head, 5);
  list1_head = insert_at_head(list1_head, 3);
  print_list(list1_head);
  printf("\n");


  // Test out the function to insert elements at the tail of the list
  printf("\ninsert_at_tail test\n");
  printf("****************************************\n\n"); 
  list1_head = insert_at_tail(list1_head, 10);
  list1_head = insert_at_tail(list1_head, 12);
  print_list(list1_head);
  printf("\n");


  // Test out the function to delete elements at the head of the list
  printf("\ndelete_at_head test\n");
  printf("****************************************\n\n");   
  list1_head = delete_at_head(list1_head);
  list1_head = delete_at_head(list1_head);
  print_list(list1_head);
  printf("\n");


  // Test out the function to delete elements at the tail of the list
  printf("\ndelete_at_tail test\n");
  printf("****************************************\n\n");   
  list1_head = delete_at_tail(list1_head);
  print_list(list1_head);
  printf("\n");


  // Do a performance comparison of a linked list vs. an array where we have 
  // 10,000 elements/nodes in each data structure with values from 0...9,999.
  // 
  // Compare the performance of deleting the first element in each data 
  // structure entirely from memory.  Delete the first element 10,000 times 
  // so that we are eventually left with a "blank" array and linked list.
  // 
  // With an array, this will mean re-allocating space for the array that is 
  // one element smaller than the previous array, and copying the old array 
  // (minus the first element) into the new array.  
  //
  // With a linked list, this will mean deleting the head node.
  //
  // Though this situation is definitely contrived, it does illustrate the 
  // large performance difference!
  //

  // Variables used as part of our testing
  int num_elements = 10000;
  clock_t tic, toc;
  printf("\narray vs linked list performance test\n");
  printf("****************************************\n\n"); 

  // Allocate and initialize the initial array of 10,000 elements
  int *array = malloc(num_elements * sizeof(int));
  for (int i = 0; i < num_elements; i++) array[i] = i;

  // Test the performance of deleting each element from the array, one element 
  // at a time, including copying the old array data into the new smaller array
  tic = clock();
  for (int i = 0; i < num_elements; i++)
  {
    int *newarray = malloc( (num_elements - i) * sizeof(int) );
    for (int j = 0; j < num_elements - i; j++)
    {
      newarray[j] = array[j + 1];
    }
    free(array);
    array = newarray;
  }
  toc = clock();
  printf("Array test time elapsed: %f seconds\n", 
         (double)(toc - tic) / CLOCKS_PER_SEC );
  free(array);

  // Create a linked list and initialize it with the 10,000 nodes
  Node *listp = NULL;
  for (int i = 0; i < num_elements; i++) listp = insert_at_head(listp, i);

  // Test the performance of deleting all 10000 list nodes one at a time
  tic = clock();
  for (int i = 0; i < num_elements; i++) listp = delete_at_head(listp);
  toc = clock();
  printf("Linked List test time elapsed: %f seconds\n", 
         (double)(toc - tic) / CLOCKS_PER_SEC );
  printf("\n");

  // Test the length functions to compute the length of the list
  printf("\nrecursive_length test\n");
  printf("****************************************\n\n"); 
  list1_head = insert_at_head(list1_head, 5);
  print_list(list1_head);
  printf("\nlength: %d\n", length(list1_head));
  printf("\nrecursive computed length: %d\n", recursive_length(list1_head));
  printf("\n");


  // Test the is_member function
  printf("\nis_member test\n");
  printf("****************************************\n\n"); 
  print_list(list1_head);
  if (is_member(list1_head, 3)) printf("3 is a member of the list\n");
  else printf("3 is not a member of the list\n");
  if (is_member(list1_head, 10)) printf("10 is a member of the list\n");
  else printf("10 is not a member of the list\n");
  printf("\n");


  // Test the count_matches function after inserting some more nodes
  printf("\ncount_matches test\n");
  printf("****************************************\n\n");  
  list1_head = insert_at_head(list1_head, 7);
  list1_head = insert_at_head(list1_head, 7);
  list1_head = insert_at_head(list1_head, 10);
  print_list(list1_head);
  printf("Number of 7s: %d\n", count_matches(list1_head, 7));
  printf("Number of 10s: %d\n", count_matches(list1_head, 10));
  printf("Number of 5s: %d\n", count_matches(list1_head, 5));
  printf("\n");


  // Test the replace_matches function
  printf("\nreplace_matches test\n");
  printf("****************************************\n\n");  
  printf("List before replacement...\n");
  print_list(list1_head);
  replace_matches(list1_head, 10, 14);
  printf("\n\nList after replacement of 10 with 14...\n");
  print_list(list1_head);
  printf("\n");
  

  // Test the delete_first_match function
  printf("\ndelete_first_match test\n");
  printf("****************************************\n\n");  
  bool deleted;
  list1_head = delete_first_match(list1_head, 10, &deleted);
  if (deleted) printf("A node with the value 10 was deleted\n");
  else printf("A node with the value 10 was not deleted\n");
  printf("\n");
  print_list(list1_head);
  printf("\n");

  list1_head = delete_first_match(list1_head, 14, &deleted);
  if (deleted) printf("A node with the value 14 was deleted\n");
  else printf("A node with the value 14 was not deleted\n");
  printf("\n");
  print_list(list1_head);
  printf("\n");

  list1_head = delete_first_match(list1_head, 14, &deleted);
  if (deleted) printf("A node with the value 14 was deleted\n");
  else printf("A node with the value 14 was not deleted\n");
  printf("\n");
  print_list(list1_head);
  printf("\n");  

  list1_head = delete_first_match(list1_head, 5, &deleted);
  if (deleted) printf("A node with the value 5 was deleted\n");
  else printf("A node with the value 5 was not deleted\n");
  printf("\n");
  print_list(list1_head);
  printf("\n");   


  // Test the delete_all_matches function
  printf("\ndelete_all_matches test\n");
  printf("****************************************\n\n");
  int num_deleted = 0;
  list1_head = delete_all_matches(list1_head, 7, &num_deleted);
  printf("List after deleting all 7s...\n");
  print_list(list1_head); 
  printf("\nDeleted: %d\n", num_deleted);

  // Test the delete_all_matches function again with a harder test case
  Node *list_try = NULL;
  list_try = insert_at_head(list_try, 8);
  list_try = insert_at_head(list_try, 8);
  list_try = insert_at_head(list_try, 7);
  list_try = insert_at_head(list_try, 8);
  list_try = insert_at_head(list_try, 8);
  list_try = insert_at_head(list_try, 6);
  list_try = insert_at_head(list_try, 8);
  list_try = insert_at_head(list_try, 5);
  list_try = insert_at_head(list_try, 8);

  printf("\nlist_try before delete all matches...\n");
  print_list(list_try);
  printf("\n");

  num_deleted = 0;
  list_try = delete_all_matches(list_try, 8, &num_deleted);

  printf("list_try after delete all matches...\n");
  print_list(list_try);
  printf("\nElements deleted: %d\n", num_deleted);
  printf("\n");


  // Test the append_list function
  printf("\nappend_list test\n");
  printf("****************************************\n");  
  Node *listA = NULL, *listB = NULL;
  for (int i = 1; i <= 3; i++) listA = insert_at_tail(listA, i);
  for (int i = 4; i <= 10; i++) listB = insert_at_tail(listB, i);
  printf("\nList A:\n");
  print_list(listA);
  printf("\nList B:\n");
  print_list(listB);
  listB = append_list(listA, listB);
  printf("\nList A after appending List B:\n");
  print_list(listA);
  printf("\n");

  // Test the reverse_list function
  printf("\nreverse_list test\n");
  printf("****************************************\n"); 
  printf("\nList A before reversal:\n");
  print_list(listA);
  listA = reverse_list(listA);
  printf("\nList A after reversal:\n");
  print_list(listA);
  printf("\n");


  // Test the sort_list function
  printf("\nsort_list test\n");
  printf("****************************************\n");  
  Node *listC = NULL;
  listC = insert_at_head(listC, 5);
  listC = insert_at_head(listC, 9);
  listC = insert_at_head(listC, 1);
  listC = insert_at_head(listC, 8);
  listC = insert_at_head(listC, 4);
  listC = insert_at_head(listC, 7);
  listC = insert_at_head(listC, 3);
  listC = insert_at_head(listC, 6);
  listC = insert_at_head(listC, 2);
  printf("\nList C before sort:\n");
  print_list(listC);
  sort_list(listC);
  printf("\nList C after sort:\n");
  print_list(listC);  
  printf("\n");


  // Test the delete_duplicates function
  printf("\ndelete_duplicates test\n");
  printf("****************************************\n");    
  Node *listD = NULL;
  listD = insert_at_head(listD, 5);
  listD = insert_at_head(listD, 5);
  listD = insert_at_head(listD, 6);
  listD = insert_at_head(listD, 7);
  listD = insert_at_head(listD, 8);
  listD = insert_at_head(listD, 1);
  listD = insert_at_head(listD, 6);
  listD = insert_at_head(listD, 8);
  listD = insert_at_head(listD, 2);
  listD = insert_at_head(listD, 8);
  listD = insert_at_head(listD, 9);
  listD = insert_at_head(listD, 7);
  listD = insert_at_head(listD, 3);
  listD = insert_at_head(listD, 6);
  printf("\nList D before delete duplicates:\n");
  print_list(listD);
  delete_duplicates(listD);
  printf("\nList D after delete duplicates:\n");
  print_list(listD);   
  printf("\n");

  // Test the insert_after function
  printf("\ninsert_after test\n");
  printf("****************************************\n"); 
  Node *list = NULL; 
  list = insert_at_tail(list, 5);
  list = insert_at_tail(list, 9);
  list = insert_at_tail(list, 1);
  list = insert_at_tail(list, 8);
  list = insert_at_tail(list, 4);  
  printf("\nList before insert:\n");
  print_list(list);
  list = insert_after(list, 20, 1);
  printf("\nList after insert:\n");
  print_list(list);
  printf("\n");


  // Test the delete_list function
  printf("\ndelete_list test\n");
  printf("****************************************\n"); 
  list = delete_list(list);
  printf("\nList after delete:\n");
  print_list(list);
  printf("\n");


  // Test the add_list function by checking three cases: one where the lists 
  // are the same length, one where the first list is shorter, and one where 
  // the second list is shorter.
  printf("\nadd_list test\n");
  printf("****************************************\n");  
  Node *list1, *list2, *list3, *list4, *list5, *list6;
  list1 = list2 = list3 = list4 = list5 = list6 = NULL; // make ALL lists empty
  for (int i = 1; i <= 5; i++) list1 = insert_at_head(list1, i);
  for (int i = 8; i >= 4 ; i--) list2 = insert_at_head(list2, i);
  printf("\nList 1...\n");
  print_list(list1);
  printf("\nList 2...\n");
  print_list(list2);  
  printf("\nList 1 after add...\n");
  add_lists(list1, list2);
  print_list(list1);
  for (int i = 1; i <= 2; i++) list3 = insert_at_head(list3, i);
  for (int i = 4; i <= 7; i++) list4 = insert_at_head(list4, i);
  printf("\nList 3...\n");
  print_list(list3);
  printf("\nList 4...\n");
  print_list(list4);  
  printf("\nList 3 after add...\n");
  add_lists(list3, list4);
  print_list(list3);
  for (int i = 4; i <= 7; i++) list5 = insert_at_head(list5, i);
  for (int i = 1; i <= 2; i++) list6 = insert_at_head(list6, i);
  printf("\nList 5...\n");
  print_list(list5);
  printf("\nList 6...\n");
  print_list(list6);  
  printf("\nList 5 after add...\n");
  add_lists(list5, list6);
  print_list(list5);


  // Test the duplicate_list function by providing it a list, and printing 
  // out the list that is returned from the function
  printf("\n\nduplicate_list test\n");
  printf("****************************************\n");  
  Node *list7 = NULL;
  for (int i = 0; i < 10; i++) list7 = insert_at_head(list7, i);
  printf("\nList 7...\n");
  print_list(list7);
  Node *list7_duplicate = duplicate_list(list7);
  printf("\nList 7 duplicate...\n");
  print_list(list7_duplicate);


  // Test whether efficient_delete_match will delete nodes with matching 
  // values and keep an accurate count of the number of nodes deleted
  printf("\n\nefficient_delete_match test\n");
  printf("****************************************\n");
  Node *list8 = NULL;
  list8 = insert_at_head(list8, 4);
  list8 = insert_at_head(list8, 3);
  list8 = insert_at_head(list8, 4);
  list8 = insert_at_head(list8, 5);
  list8 = insert_at_head(list8, 4);
  list8 = insert_at_head(list8, 4);
  list8 = insert_at_head(list8, 7);
  list8 = insert_at_head(list8, 4);
  list8 = insert_at_head(list8, 4);
  printf("\nList 8...\n");
  print_list(list8);
  num_deleted = 0;
  list8 = efficient_delete_match(list8, 4, &num_deleted);  
  printf("\nList 8 after delete...\n");
  print_list(list8);
  printf("\nNumber of elements deleted: %d\n\n\n", num_deleted);


  // Test the performance of delete_all_matches vs efficient_delete by 
  // creating lists with 50000 nodes with values from 0-10 repeated and 
  // deleting 4 from both lists.
  printf("performance test of delete functions\n");
  printf("****************************************\n\n");
  Node *list9 = NULL, *list10 = NULL;
  for (int i = 0; i < 50000; i++) list9 = insert_at_head(list9, i % 10);
  for (int i = 0; i < 50000; i++) list10 = insert_at_head(list10, i % 10);
  tic = clock();
  list9 = delete_all_matches(list9, 4, &num_deleted);
  toc = clock();
  printf("delete_all_matches: %fs\n", (double)(toc - tic) / CLOCKS_PER_SEC);
  printf("elements deleted: %d\n\n", num_deleted);
  tic = clock();
  list10 = efficient_delete_match(list10, 4, &num_deleted);
  toc = clock();
  printf("efficient_delete_match: %fs\n", (double)(toc - tic) / CLOCKS_PER_SEC);
  printf("elements deleted: %d\n\n", num_deleted);


  // Test merge_sorted_lists to see if it is able to merge two sorted 
  // lists correctly by creating two lists of length 10 with random values 
  // between 0 and 98.
  printf("\nmerge_sorted_lists test\n");
  printf("****************************************\n");
  srand(time(NULL));
  Node *list11 = NULL;
  Node *list12 = NULL;
  for (int i = 0; i < 10; i++) list11 = insert_at_head(list11, rand() % 99);
  for (int i = 0; i < 10; i++) list12 = insert_at_head(list12, rand() % 99);
  sort_list(list11);
  sort_list(list12);
  printf("\nList 11...\n");
  print_list(list11);
  printf("\nList 12...\n");
  print_list(list12);
  Node *newhead = merge_sorted_lists(list11, list12);
  printf("\nMerged list...\n");
  print_list(newhead);

  return 0;
}