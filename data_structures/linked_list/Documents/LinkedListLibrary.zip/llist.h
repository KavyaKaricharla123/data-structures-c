/**
 * Linked List Library.  Includes standard functions for insertion, deletion, 
 * membership, length, replacement, printing linked lists, etc.
 *  
 * @brief Linked List Library
 * 
 * @file llist.h
 * @author Kevin Browne
 * @date Wednesday May 12th, 2021.
 * 
 */
#include <stdbool.h>

/**
 * A node in a linked list.  Linked lists are made up of nodes that point to 
 * one another in a chain, beginning with a head node and ending with a tail 
 * node.  Each node only points to one other node, and the tail node points to
 * NULL.  Empty lists are also represented with NULL.  For more on linked lists
 * see: https://en.wikipedia.org/wiki/Linked_list
 * 
 * @brief A node in a linked list
 */ 
typedef struct node {
  int value; /**< the value stored in the node */
  struct node *next; /**< pointer to next node in list, NULL for tail node */
} Node;

void print_list(Node *head);
Node *insert_at_head(Node *head, int new_value);
Node *insert_at_tail(Node *head, int new_value);
Node *delete_at_head(Node *head);
Node *delete_at_tail(Node *head);
int length(Node *head);
int recursive_length(Node *node);
bool is_member(Node *node, int find_value);
int count_matches(Node *node, int find_value);
void replace_matches(Node *node, int find_value, 
                     int replace_value);
Node *delete_first_match(Node *head, int delete_value,
                         bool *was_deleted);
Node *delete_all_matches(Node *head, int delete_value,
                         int *num_deleted);
Node *efficient_delete_match(Node *head, int delete_value,
                             int *num_deleted);
Node *append_list(Node *head1, Node *head2);
Node *reverse_list(Node *head);
void sort_list(Node *head);
void delete_duplicates(Node *head);
Node *insert_after(Node *head, int new_value,
                   int after_value);
Node *delete_list(Node *node);
void add_lists(Node *list1, Node *list2);
Node *duplicate_list(Node *node);
Node *merge_sorted_lists(Node *list1, Node *list2);