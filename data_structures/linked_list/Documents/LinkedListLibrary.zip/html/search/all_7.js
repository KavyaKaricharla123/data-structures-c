var searchData=
[
  ['next_21',['next',['../structnode.html#aa3e8aa83f864292b5a01210f4453fcc0',1,'node']]],
  ['node_22',['node',['../structnode.html',1,'']]],
  ['node_23',['Node',['../llist_8h.html#ac09cf950484bd9550d14d602b0e5e7fb',1,'llist.h']]]
];
