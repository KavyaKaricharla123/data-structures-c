var searchData=
[
  ['count_5fmatches_2',['count_matches',['../llist_8c.html#a3bec386b071acc83616c3e7dbb9add49',1,'count_matches(Node *node, int find_value):&#160;llist.c'],['../llist_8h.html#a3bec386b071acc83616c3e7dbb9add49',1,'count_matches(Node *node, int find_value):&#160;llist.c']]]
];
