var searchData=
[
  ['recursive_5flength_25',['recursive_length',['../llist_8c.html#aaa82d1becdb90f231c77664a5a423182',1,'recursive_length(Node *node):&#160;llist.c'],['../llist_8h.html#aaa82d1becdb90f231c77664a5a423182',1,'recursive_length(Node *node):&#160;llist.c']]],
  ['replace_5fmatches_26',['replace_matches',['../llist_8c.html#a64d3ec95e4c80bcc717409695b66fb7c',1,'replace_matches(Node *node, int find_value, int replace_value):&#160;llist.c'],['../llist_8h.html#a64d3ec95e4c80bcc717409695b66fb7c',1,'replace_matches(Node *node, int find_value, int replace_value):&#160;llist.c']]],
  ['reverse_5flist_27',['reverse_list',['../llist_8c.html#a00de092f8604c26aed0607d60f611fd5',1,'reverse_list(Node *head):&#160;llist.c'],['../llist_8h.html#a00de092f8604c26aed0607d60f611fd5',1,'reverse_list(Node *head):&#160;llist.c']]]
];
