var indexSectionsWithContent =
{
  0: "acdeilmnprsv",
  1: "n",
  2: "lm",
  3: "acdeilmprs",
  4: "nv",
  5: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs"
};

