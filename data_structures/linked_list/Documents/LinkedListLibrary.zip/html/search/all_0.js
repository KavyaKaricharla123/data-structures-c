var searchData=
[
  ['add_5flists_0',['add_lists',['../llist_8c.html#a5e716051b14c8440070fd6dc9465a0fe',1,'add_lists(Node *list1, Node *list2):&#160;llist.c'],['../llist_8h.html#a5e716051b14c8440070fd6dc9465a0fe',1,'add_lists(Node *list1, Node *list2):&#160;llist.c']]],
  ['append_5flist_1',['append_list',['../llist_8c.html#ae97733456b91617f8af9cd47096c4c05',1,'append_list(Node *head1, Node *head2):&#160;llist.c'],['../llist_8h.html#ae97733456b91617f8af9cd47096c4c05',1,'append_list(Node *head1, Node *head2):&#160;llist.c']]]
];
