var searchData=
[
  ['delete_5fall_5fmatches_3',['delete_all_matches',['../llist_8c.html#a2a6f4132b0e94af244ff27d04bc77774',1,'delete_all_matches(Node *head, int delete_value, int *num_deleted):&#160;llist.c'],['../llist_8h.html#a2a6f4132b0e94af244ff27d04bc77774',1,'delete_all_matches(Node *head, int delete_value, int *num_deleted):&#160;llist.c']]],
  ['delete_5fat_5fhead_4',['delete_at_head',['../llist_8c.html#a62669feda61b2a7e96df408d045d0636',1,'delete_at_head(Node *head):&#160;llist.c'],['../llist_8h.html#a62669feda61b2a7e96df408d045d0636',1,'delete_at_head(Node *head):&#160;llist.c']]],
  ['delete_5fat_5ftail_5',['delete_at_tail',['../llist_8c.html#a72bfcbb6f58724bae585547a010775c6',1,'delete_at_tail(Node *head):&#160;llist.c'],['../llist_8h.html#a72bfcbb6f58724bae585547a010775c6',1,'delete_at_tail(Node *head):&#160;llist.c']]],
  ['delete_5fduplicates_6',['delete_duplicates',['../llist_8c.html#ad8741d2fac199ed30daca4ed88199b00',1,'delete_duplicates(Node *head):&#160;llist.c'],['../llist_8h.html#ad8741d2fac199ed30daca4ed88199b00',1,'delete_duplicates(Node *head):&#160;llist.c']]],
  ['delete_5ffirst_5fmatch_7',['delete_first_match',['../llist_8c.html#a22e8043aef6dcd43c37741aa0d2b42fa',1,'delete_first_match(Node *head, int delete_value, bool *was_deleted):&#160;llist.c'],['../llist_8h.html#a22e8043aef6dcd43c37741aa0d2b42fa',1,'delete_first_match(Node *head, int delete_value, bool *was_deleted):&#160;llist.c']]],
  ['delete_5flist_8',['delete_list',['../llist_8c.html#a13bd6d089f49749f9a109d515f30abe5',1,'delete_list(Node *node):&#160;llist.c'],['../llist_8h.html#a13bd6d089f49749f9a109d515f30abe5',1,'delete_list(Node *node):&#160;llist.c']]],
  ['duplicate_5flist_9',['duplicate_list',['../llist_8c.html#a5a46f48081393d8c648df94c59eae49a',1,'duplicate_list(Node *node):&#160;llist.c'],['../llist_8h.html#a5a46f48081393d8c648df94c59eae49a',1,'duplicate_list(Node *node):&#160;llist.c']]]
];
