var searchData=
[
  ['efficient_5fdelete_5fmatch_10',['efficient_delete_match',['../llist_8c.html#a353703e962d4c3a086352a56f208f35a',1,'efficient_delete_match(Node *head, int delete_value, int *num_deleted):&#160;llist.c'],['../llist_8h.html#a353703e962d4c3a086352a56f208f35a',1,'efficient_delete_match(Node *head, int delete_value, int *num_deleted):&#160;llist.c']]]
];
